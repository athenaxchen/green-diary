// 个人中心
import { store, resetAll } from '../store.js';
import { toast, escapeHtml, openModal, closeModal } from '../utils.js';

export function renderProfile(view) {
  const u = store.user;
  const totalDiary = store.myPlants.reduce((s, p) => s + p.diary.length, 0);
  const completedTasks = store.tasks.filter(t => t.done).length;

  view.innerHTML = `
    <section class="page">
      <header class="page-header">
        <h1 class="page-title">我的 👤</h1>
      </header>

      <div class="profile-header">
        <div class="profile-info">
          <div class="profile-avatar">🌱</div>
          <div>
            <div class="profile-name">${escapeHtml(u.name)}</div>
            <div class="profile-tag">${escapeHtml(u.tag)}</div>
          </div>
        </div>
      </div>

      <div class="stat-row">
        <div class="stat-item"><div class="stat-num">${store.myPlants.length}</div><div class="stat-label">我的植物</div></div>
        <div class="stat-item"><div class="stat-num">${u.streakDays}</div><div class="stat-label">连续打卡</div></div>
        <div class="stat-item"><div class="stat-num">${u.totalDays}</div><div class="stat-label">养护天数</div></div>
      </div>

      <div class="section-title">
        <h3>我的成就</h3>
        <span class="more">${u.achievements.filter(a=>a.unlocked).length} / ${u.achievements.length}</span>
      </div>

      <div class="achievement-grid">
        ${u.achievements.map(a => `
          <div class="achievement ${a.unlocked ? '' : 'locked'}">
            <div class="achievement-icon">${a.icon}</div>
            <div class="achievement-name">${escapeHtml(a.name)}</div>
          </div>
        `).join('')}
      </div>

      <div class="section-title">
        <h3>数据概览</h3>
      </div>

      <div class="stat-row" style="grid-template-columns:1fr 1fr;">
        <div class="stat-item" style="text-align:left;padding:14px;">
          <div style="display:flex;align-items:center;gap:8px;color:var(--color-text-light);font-size:12px;margin-bottom:4px;">
            <i class="ri-book-2-line" style="color:var(--color-primary);"></i> 日记总数
          </div>
          <div class="stat-num" style="font-size:22px;">${totalDiary}<span style="font-size:12px;font-weight:600;color:var(--color-text-light);"> 篇</span></div>
        </div>
        <div class="stat-item" style="text-align:left;padding:14px;">
          <div style="display:flex;align-items:center;gap:8px;color:var(--color-text-light);font-size:12px;margin-bottom:4px;">
            <i class="ri-checkbox-circle-line" style="color:var(--color-primary);"></i> 已完成任务
          </div>
          <div class="stat-num" style="font-size:22px;">${completedTasks}<span style="font-size:12px;font-weight:600;color:var(--color-text-light);"> 项</span></div>
        </div>
      </div>

      <div class="section-title">
        <h3>设置与帮助</h3>
      </div>

      <div class="menu-list">
        <div class="menu-item" data-action="share">
          <i class="ri-qr-code-line" style="background:rgba(232,168,124,0.15);color:#C97B3F;"></i>
          <span class="menu-item-text">分享小程序码</span>
          <span style="font-size:12px;color:var(--color-text-muted);">邀请好友一起种</span>
          <i class="ri-arrow-right-s-line menu-item-arrow"></i>
        </div>
        <div class="menu-item" data-action="reminder">
          <i class="ri-notification-3-line"></i>
          <span class="menu-item-text">养护提醒</span>
          <span style="font-size:12px;color:var(--color-text-muted);">每日 9:00</span>
          <i class="ri-arrow-right-s-line menu-item-arrow"></i>
        </div>
        <div class="menu-item" data-action="theme">
          <i class="ri-palette-line"></i>
          <span class="menu-item-text">主题外观</span>
          <span style="font-size:12px;color:var(--color-text-muted);">薄荷绿</span>
          <i class="ri-arrow-right-s-line menu-item-arrow"></i>
        </div>
        <div class="menu-item" data-action="export">
          <i class="ri-download-cloud-2-line"></i>
          <span class="menu-item-text">数据导出</span>
          <i class="ri-arrow-right-s-line menu-item-arrow"></i>
        </div>
        <div class="menu-item" data-action="about">
          <i class="ri-information-line"></i>
          <span class="menu-item-text">关于绿野手记</span>
          <span style="font-size:12px;color:var(--color-text-muted);">v1.0.0</span>
          <i class="ri-arrow-right-s-line menu-item-arrow"></i>
        </div>
        <div class="menu-item" data-action="reset">
          <i class="ri-restart-line" style="background:rgba(232,168,124,0.15);color:#C97B3F;"></i>
          <span class="menu-item-text">重置体验数据</span>
          <i class="ri-arrow-right-s-line menu-item-arrow"></i>
        </div>
      </div>

      <div style="text-align:center;margin-top:20px;font-size:11px;color:var(--color-text-muted);line-height:1.7;">
        🌿 让每一株植物都被温柔以待<br/>
        感谢你陪伴它们一路生长
      </div>
    </section>
  `;

  view.querySelectorAll('.menu-item').forEach(m => {
    m.addEventListener('click', () => handleMenu(m.dataset.action, view));
  });
}

function handleMenu(action, view) {
  if (action === 'reset') {
    if (confirm('确定要重置所有体验数据吗？已添加的植物、日记、任务都会还原。')) {
      resetAll();
      toast('🔄 数据已重置');
    }
  } else if (action === 'export') {
    toast('📥 导出功能开发中…');
  } else if (action === 'reminder') {
    toast('🔔 提醒已开启');
  } else if (action === 'theme') {
    toast('🎨 更多主题开发中…');
  } else if (action === 'about') {
    toast('🌱 绿野手记 · v1.0.0 体验版');
  } else if (action === 'share') {
    openShareCard();
  }
}

/* ========== 分享小程序码 ========== */
function openShareCard() {
  const u = store.user;
  const plantsCount = store.myPlants.length;
  const shareUrl = window.location.href.split('#')[0];

  openModal(`
    <div class="modal-header">
      <span class="modal-title">分享小程序码 🎁</span>
      <button class="modal-close" data-close><i class="ri-close-line"></i></button>
    </div>
    <div class="modal-body" style="padding-bottom:16px;">
      <p style="font-size:12px;color:var(--color-text-light);margin-bottom:12px;line-height:1.6;">
        把这张卡片分享给朋友，邀请 TA 一起开启植物养成之旅 🌿
      </p>

      <!-- 可截图卡片 -->
      <div class="share-card" id="share-card">
        <div class="share-card-bg">
          <span class="leaf leaf-1">🌿</span>
          <span class="leaf leaf-2">🌱</span>
          <span class="leaf leaf-3">🍃</span>
          <span class="leaf leaf-4">🌵</span>
        </div>

        <div class="share-card-header">
          <div class="share-card-logo">🌿</div>
          <div class="share-card-brand">
            <div class="share-card-app">绿野手记</div>
            <div class="share-card-slogan">让每株植物都被温柔以待</div>
          </div>
        </div>

        <div class="share-card-user">
          <div class="share-card-avatar">🌱</div>
          <div>
            <div class="share-card-username">${escapeHtml(u.name)}</div>
            <div class="share-card-meta">陪伴 ${plantsCount} 株植物 · 连续打卡 ${u.streakDays} 天</div>
          </div>
        </div>

        <div class="share-card-invite">
          <div class="share-card-invite-title">"和我一起种点小绿吧 🌱"</div>
          <div class="share-card-invite-sub">扫码 / 长按识别 立刻加入</div>
        </div>

        <div class="share-card-qr-wrap">
          <div class="share-card-qr" id="share-qr"></div>
        </div>

        <div class="share-card-footer">
          <span>🌿 GreenDiary · v1.0</span>
          <span>${new Date().getFullYear()} 邀您共赏</span>
        </div>
      </div>

      <div class="share-actions">
        <button class="btn btn-ghost" id="share-copy">
          <i class="ri-link"></i> 复制链接
        </button>
        <button class="btn btn-primary" id="share-save">
          <i class="ri-download-2-line"></i> 保存图片
        </button>
      </div>

      <p style="font-size:11px;color:var(--color-text-muted);text-align:center;margin-top:10px;line-height:1.6;">
        长按图片也可保存到相册 · 分享给好友更便捷
      </p>
    </div>
  `);

  // 生成二维码
  const qrEl = document.getElementById('share-qr');
  if (qrEl && window.QRCode) {
    try {
      new window.QRCode(qrEl, {
        text: shareUrl,
        width: 110,
        height: 110,
        colorDark: '#3A5A40',
        colorLight: '#ffffff',
        correctLevel: window.QRCode.CorrectLevel.H,
      });
    } catch (e) {
      qrEl.innerHTML = `<div style="font-size:11px;color:#999;padding:12px;text-align:center;">二维码加载失败</div>`;
    }
  }

  // 复制链接
  document.getElementById('share-copy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast('🔗 链接已复制，快去分享吧～');
    } catch (e) {
      // 兜底方案
      const ta = document.createElement('textarea');
      ta.value = shareUrl;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); toast('🔗 链接已复制'); }
      catch (_) { toast('复制失败，请手动复制：' + shareUrl); }
      ta.remove();
    }
  });

  // 保存图片
  document.getElementById('share-save').addEventListener('click', async () => {
    const card = document.getElementById('share-card');
    if (!card || !window.html2canvas) {
      toast('图片生成失败，请稍后重试');
      return;
    }
    toast('🎨 正在生成图片...');
    try {
      const canvas = await window.html2canvas(card, {
        backgroundColor: null,
        scale: 2,
        useCORS: true,
        logging: false,
      });
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.download = `绿野手记-${u.name}-邀请卡.png`;
      a.href = dataUrl;
      a.click();
      toast('✅ 已保存到下载，快去分享吧 🎉');
    } catch (e) {
      console.error(e);
      toast('图片生成失败，可尝试长按卡片保存');
    }
  });
}