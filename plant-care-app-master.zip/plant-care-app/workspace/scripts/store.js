// 全局状态管理（带 LocalStorage 持久化）
import { MY_PLANTS, TASKS, HEALTH_HISTORY, USER } from './data.js';

const STORAGE_KEY = 'green_diary_v1';

const initialState = {
  myPlants: JSON.parse(JSON.stringify(MY_PLANTS)),
  tasks: JSON.parse(JSON.stringify(TASKS)),
  healthHistory: JSON.parse(JSON.stringify(HEALTH_HISTORY)),
  user: JSON.parse(JSON.stringify(USER)),
};

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      return { ...initialState, ...data };
    }
  } catch (e) { /* ignore */ }
  return initialState;
}

function save(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) { /* ignore */ }
}

export const store = load();

const listeners = new Set();
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
export function notify() {
  save(store);
  listeners.forEach(fn => fn(store));
}

/* ========== Mutations ========== */
export function toggleTask(id) {
  const t = store.tasks.find(x => x.id === id);
  if (!t) return;
  t.done = !t.done;
  notify();
}

export function addPlant(plant) {
  const id = 'm' + Date.now();
  store.myPlants.unshift({
    id,
    plantId: plant.plantId,
    nick: plant.nick || plant.species,
    species: plant.species,
    img: plant.img,
    location: plant.location || '未指定',
    adoptDate: new Date().toISOString().slice(0, 10),
    health: 'good',
    diary: [
      { id: 'd' + Date.now(), type: 'photo', title: '加入小院 🎉', time: '刚刚', note: '欢迎你的到来！' }
    ]
  });
  store.user.totalPlants = store.myPlants.length;
  // 自动生成首条任务
  store.tasks.unshift({
    id: 't' + Date.now(),
    plantId: id,
    type: 'water',
    done: false,
    dayOffset: 1,
    desc: `给${plant.nick || plant.species}浇水`,
  });
  notify();
  return id;
}

export function addDiary(myPlantId, entry) {
  const p = store.myPlants.find(x => x.id === myPlantId);
  if (!p) return;
  p.diary.unshift({
    id: 'd' + Date.now(),
    time: '刚刚',
    ...entry,
  });
  notify();
}

export function updatePlantImage(myPlantId, imgDataUrl) {
  const p = store.myPlants.find(x => x.id === myPlantId);
  if (!p) return;
  p.img = imgDataUrl;
  // 同步追加一条日记，记录"换装"时刻
  p.diary.unshift({
    id: 'd' + Date.now(),
    type: 'photo',
    title: '更新头像 📸',
    time: '刚刚',
    note: '换上了最新的样子',
  });
  notify();
}

export function addHealthRecord(rec) {
  store.healthHistory.unshift({
    id: 'h' + Date.now(),
    date: '刚刚',
    ...rec,
  });
  // 限制最多 12 条
  if (store.healthHistory.length > 12) store.healthHistory.length = 12;
  notify();
}

export function deletePlant(myPlantId) {
  const idx = store.myPlants.findIndex(x => x.id === myPlantId);
  if (idx >= 0) {
    store.myPlants.splice(idx, 1);
    store.tasks = store.tasks.filter(t => t.plantId !== myPlantId);
    store.user.totalPlants = store.myPlants.length;
    notify();
  }
}

export function resetAll() {
  localStorage.removeItem(STORAGE_KEY);
  Object.assign(store, JSON.parse(JSON.stringify({
    myPlants: MY_PLANTS,
    tasks: TASKS,
    healthHistory: HEALTH_HISTORY,
    user: USER,
  })));
  notify();
}