// 任务页：今日任务 / 周历
import { store, toggleTask } from '../store.js';
import { TASK_TYPES } from '../data.js';
import { todayStr, getWeekDays, escapeHtml, toast } from '../utils.js';

let activeOffset = 0;

export function renderTasks(view) {
  const days = getWeekDays();
  // 重置 activeOffset 确保有效
  if (!days.find(d => d.offset === activeOffset)) activeOffset = 0;

  const allTodayTasks = store.tasks.filter(t => t.dayOffset === activeOffset);
  const todayTasks = store.tasks.filter(t => t.dayOffset === 0);
  const doneToday = todayTasks.filter(t => t.done).length;
  const totalToday = todayTasks.length;
  const progressPct = totalToday ? Math.round(doneToday / totalToday * 100) : 0;

  view.innerHTML = `
    <section class="page">
      <div class="task-hero">
        <div class="task-hero-date">${todayStr()}</div>
        <div class="task-hero-title">今日待办 ${totalToday > 0 ? `${doneToday}/${totalToday}` : '✨ 全部完成'}</div>
        <div class="progress" style="margin-bottom:12px;background:rgba(255,255,255,0.3);">
          <div class="progress-bar" style="width:${progressPct}%;background:#fff;"></div>
        </div>
        <div class="task-hero-stats">
          <div class="task-hero-stat"><strong>${doneToday}</strong>已完成</div>
          <div class="task-hero-stat"><strong>${totalToday - doneToday}</strong>待处理</div>
          <div class="task-hero-stat"><strong>${store.user.streakDays}</strong>连续打卡</div>
        </div>
      </div>

      <div class="section-title">
        <h3>本周日历</h3>
        <span class="more">点击查看每日任务</span>
      </div>

      <div class="week-strip" id="week-strip">
        ${days.map(d => {
          const has = store.tasks.some(t => t.dayOffset === d.offset);
          return `
            <button class="week-day ${d.isToday ? 'today' : ''} ${has ? 'has-task' : ''} ${d.offset === activeOffset && !d.isToday ? 'active' : ''}" data-offset="${d.offset}">
              <div>周${d.label}</div>
              <span class="wd-num">${d.num}</span>
            </button>
          `;
        }).join('')}
      </div>

      <div class="section-title">
        <h3>${activeOffset === 0 ? '今日任务' : (activeOffset > 0 ? `${activeOffset}天后` : `${-activeOffset}天前`)}</h3>
        <span class="more">${allTodayTasks.length} 项</span>
      </div>

      ${allTodayTasks.length === 0 ? `
        <div class="empty">
          <span class="empty-icon">${activeOffset === 0 ? '🎉' : '📅'}</span>
          <div class="empty-text">${activeOffset === 0 ? '今天没有任务，可以休息一下啦～' : '这一天暂无安排'}</div>
        </div>
      ` : `
        <div class="task-list">
          ${allTodayTasks.map(taskItemHtml).join('')}
        </div>
      `}

      <div style="margin-top:20px;padding:14px 16px;background:rgba(127,176,105,0.08);border-radius:14px;font-size:12px;color:var(--color-text-light);line-height:1.7;">
        <div style="font-weight:800;color:var(--color-secondary);margin-bottom:4px;">🌿 今日小贴士</div>
        ${getDailyTip()}
      </div>
    </section>
  `;

  // 事件
  view.querySelectorAll('.week-day').forEach(b => {
    b.addEventListener('click', () => {
      activeOffset = parseInt(b.dataset.offset);
      renderTasks(view);
    });
  });
  view.querySelectorAll('.task-check').forEach(c => {
    c.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = c.dataset.id;
      toggleTask(id);
      const wasDone = store.tasks.find(t => t.id === id)?.done;
      if (wasDone) toast('✅ 完成啦，植物会感谢你 🌿');
    });
  });
}

function taskItemHtml(t) {
  const plant = store.myPlants.find(p => p.id === t.plantId);
  if (!plant) return '';
  const type = TASK_TYPES[t.type] || { label: '任务', icon: 'ri-checkbox-circle-line', tag: 'tag-water' };
  return `
    <div class="task-card ${t.done ? 'done' : ''}">
      <div class="task-check ${t.done ? 'checked' : ''}" data-id="${t.id}">
        <i class="ri-check-line"></i>
      </div>
      <div class="task-info">
        <div class="task-name">${escapeHtml(t.desc)}</div>
        <div class="task-plant">
          <img src="${plant.img}" alt="${escapeHtml(plant.nick)}" />
          <span>${escapeHtml(plant.nick)}</span>
          <span class="task-tag ${type.tag}" style="margin-left:6px;"><i class="${type.icon}"></i>${type.label}</span>
        </div>
      </div>
    </div>
  `;
}

const TIPS = [
  '春季是植物生长旺盛期，记得增加施肥频次，但浓度要稀。',
  '浇水前先用手指探入土壤2cm，干燥再浇透，最稳妥。',
  '叶面有灰尘会影响光合作用，每周用湿布轻擦一次。',
  '阳台党记得每周给植物转一下方向，避免一边倒。',
  '植物的叶片会"说话"：黄叶查水分，焦边看湿度，蔫软看根系。',
  '雨季注意通风，潮湿环境最容易招来病虫害。',
  '冬季少施肥少浇水，让植物好好休息一下吧～',
];
function getDailyTip() {
  const i = new Date().getDate() % TIPS.length;
  return TIPS[i];
}