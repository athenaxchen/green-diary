// 工具函数：DOM、Toast、Modal、动画等
export function $(sel, root = document) { return root.querySelector(sel); }
export function $$(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }

export function el(html) {
  const tpl = document.createElement('template');
  tpl.innerHTML = html.trim();
  return tpl.content.firstElementChild;
}

let toastTimer = null;
export function toast(msg, duration = 1800) {
  const t = document.getElementById('toast');
  t.innerHTML = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), duration);
}

export function openModal(htmlContent) {
  const mask = document.getElementById('modal-mask');
  mask.innerHTML = '';
  const modal = el(`<div class="modal">${htmlContent}</div>`);
  mask.appendChild(modal);
  mask.classList.add('show');
  // 关闭事件
  const close = () => closeModal();
  mask.onclick = (e) => { if (e.target === mask) close(); };
  modal.querySelectorAll('[data-close]').forEach(b => b.onclick = close);
  return modal;
}

export function closeModal() {
  const mask = document.getElementById('modal-mask');
  mask.classList.remove('show');
  setTimeout(() => { mask.innerHTML = ''; }, 220);
}

export function ripple(e, target) {
  const wrap = target || e.currentTarget;
  if (!wrap) return;
  wrap.classList.add('ripple-wrap');
  const r = document.createElement('span');
  r.className = 'ripple';
  const rect = wrap.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height);
  r.style.width = r.style.height = size + 'px';
  r.style.left = (e.clientX - rect.left - size / 2) + 'px';
  r.style.top = (e.clientY - rect.top - size / 2) + 'px';
  wrap.appendChild(r);
  setTimeout(() => r.remove(), 700);
}

export function difficultyStars(n) {
  return '★'.repeat(n) + '☆'.repeat(3 - n);
}

export function difficultyBadge(n) {
  if (n <= 1) return '<span class="badge badge-easy">易养</span>';
  if (n === 2) return '<span class="badge badge-medium">进阶</span>';
  return '<span class="badge badge-hard">挑战</span>';
}

export function getWeekDays() {
  const today = new Date();
  const dow = today.getDay() || 7; // 周一开始：1-7
  const start = new Date(today);
  start.setDate(today.getDate() - (dow - 1));
  const days = [];
  const labels = ['一','二','三','四','五','六','日'];
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    days.push({
      label: labels[i],
      num: d.getDate(),
      date: d,
      isToday: d.toDateString() === today.toDateString(),
      offset: Math.round((d - today) / (1000 * 60 * 60 * 24)),
    });
  }
  return days;
}

export function todayStr() {
  const d = new Date();
  const m = d.getMonth() + 1;
  const day = d.getDate();
  const w = ['周日','周一','周二','周三','周四','周五','周六'][d.getDay()];
  return `${m}月${day}日 · ${w}`;
}

export function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}
