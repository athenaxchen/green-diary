// 发现页：植物百科
import { PLANTS, CATEGORIES, IMG } from '../data.js';
import { addPlant } from '../store.js';
import { openModal, closeModal, toast, escapeHtml, difficultyStars, difficultyBadge, $$ } from '../utils.js';

let currentCategory = 'all';
let currentKeyword = '';

export function renderDiscover(view) {
  const filtered = filterPlants();
  view.innerHTML = `
    <section class="page">
      <header class="page-header">
        <h1 class="page-title">发现植物 🌿</h1>
        <p class="page-subtitle">遇见你的下一株小绿伙伴</p>
      </header>

      <div class="search-bar">
        <i class="ri-search-line"></i>
        <input id="search-input" type="text" placeholder="搜索植物名称、习性..." value="${escapeHtml(currentKeyword)}" />
      </div>

      <div class="discover-banner">
        <img src="${IMG.banner}" alt="植物精选" loading="lazy" />
        <div class="discover-banner-overlay">
          <h2>🌱 春日精选 · 新手必养</h2>
          <p>16 种好看又好养的小绿宝，总有一款适合你</p>
        </div>
      </div>

      <div class="chip-row" id="chip-row">
        ${CATEGORIES.map(c => `
          <button class="chip ${currentCategory === c.key ? 'active' : ''}" data-cat="${c.key}">
            <span>${c.icon}</span><span>${c.label}</span>
          </button>
        `).join('')}
      </div>

      <div class="section-title">
        <h3>植物图鉴 <span style="font-weight:600;font-size:13px;color:var(--color-text-muted);">· ${filtered.length} 种</span></h3>
      </div>

      ${filtered.length === 0 ? `
        <div class="empty">
          <span class="empty-icon">🍂</span>
          <div class="empty-text">没有找到相关植物，换个关键词试试～</div>
        </div>
      ` : `
        <div class="plant-grid" id="plant-grid">
          ${filtered.map(p => plantCardHtml(p)).join('')}
        </div>
      `}
    </section>
  `;

  // 绑定事件
  view.querySelector('#search-input').addEventListener('input', (e) => {
    currentKeyword = e.target.value.trim();
    renderDiscover(view);
    view.querySelector('#search-input').focus();
  });
  view.querySelectorAll('#chip-row .chip').forEach(btn => {
    btn.addEventListener('click', () => {
      currentCategory = btn.dataset.cat;
      renderDiscover(view);
    });
  });
  view.querySelectorAll('.plant-card').forEach(card => {
    card.addEventListener('click', () => openPlantDetail(card.dataset.id));
  });
}

function filterPlants() {
  return PLANTS.filter(p => {
    const matchCat = currentCategory === 'all' || p.category.includes(currentCategory);
    const kw = currentKeyword.toLowerCase();
    const matchKw = !kw || p.name.toLowerCase().includes(kw) || p.latin.toLowerCase().includes(kw)
      || p.category.some(c => c.toLowerCase().includes(kw));
    return matchCat && matchKw;
  });
}

function plantCardHtml(p) {
  return `
    <article class="plant-card" data-id="${p.id}">
      <img class="plant-card-img" src="${p.img}" alt="${escapeHtml(p.name)}" loading="lazy" />
      <div class="plant-card-body">
        <div class="plant-card-name">
          <span>${escapeHtml(p.name)}</span>
          ${difficultyBadge(p.difficulty)}
        </div>
        <div class="plant-card-meta">
          <span><i class="ri-sun-line"></i>${escapeHtml(p.light)}</span>
          <span><i class="ri-drop-line"></i>${escapeHtml(p.water)}</span>
        </div>
      </div>
    </article>
  `;
}

function openPlantDetail(id) {
  const p = PLANTS.find(x => x.id === id);
  if (!p) return;
  openModal(`
    <img class="detail-cover" src="${p.img}" alt="${escapeHtml(p.name)}" />
    <div class="modal-header" style="position:absolute;top:0;right:0;left:0;background:transparent;">
      <span></span>
      <button class="modal-close" data-close style="background:rgba(255,255,255,0.85);"><i class="ri-close-line"></i></button>
    </div>
    <div class="detail-content">
      <div class="detail-title-row">
        <div>
          <div class="detail-name">${escapeHtml(p.name)}</div>
          <div class="detail-latin">${escapeHtml(p.latin)}</div>
        </div>
        <div style="text-align:right;">
          ${difficultyBadge(p.difficulty)}
          <div class="stars" style="margin-top:4px;">${difficultyStars(p.difficulty)}</div>
        </div>
      </div>

      <div class="detail-tags">
        ${p.category.map(c => `<span class="chip" style="padding:3px 10px;font-size:11px;">${c}</span>`).join('')}
      </div>

      <div class="detail-attrs">
        <div class="detail-attr"><i class="ri-sun-line"></i><div><span class="detail-attr-label">光照</span><span class="detail-attr-value">${escapeHtml(p.light)}</span></div></div>
        <div class="detail-attr"><i class="ri-drop-line"></i><div><span class="detail-attr-label">浇水</span><span class="detail-attr-value">${escapeHtml(p.water)}</span></div></div>
        <div class="detail-attr"><i class="ri-temp-cold-line"></i><div><span class="detail-attr-label">温度</span><span class="detail-attr-value">${escapeHtml(p.temp)}</span></div></div>
        <div class="detail-attr"><i class="ri-mist-line"></i><div><span class="detail-attr-label">湿度</span><span class="detail-attr-value">${escapeHtml(p.humidity)}</span></div></div>
      </div>

      <div class="detail-section">
        <h4><i class="ri-information-line"></i>植物档案</h4>
        <p>${escapeHtml(p.desc)}</p>
      </div>

      <div class="detail-section">
        <h4><i class="ri-lightbulb-flash-line"></i>养护要点</h4>
        <ul class="detail-tips">
          ${p.tips.map(t => `<li>${escapeHtml(t)}</li>`).join('')}
        </ul>
      </div>

      <div class="detail-section">
        <h4><i class="ri-shield-check-line"></i>安全提示</h4>
        <p>${escapeHtml(p.toxic)}</p>
      </div>

      <button class="btn btn-primary btn-block" id="adopt-btn" style="margin-top:18px;">
        <i class="ri-add-circle-line"></i> 加入我的小院
      </button>
    </div>
  `);

  document.getElementById('adopt-btn').addEventListener('click', () => {
    closeModal();
    setTimeout(() => openAdoptForm(p), 220);
  });
}

function openAdoptForm(p) {
  openModal(`
    <div class="modal-header">
      <span class="modal-title">迎接 ${escapeHtml(p.name)} 🌱</span>
      <button class="modal-close" data-close><i class="ri-close-line"></i></button>
    </div>
    <div class="modal-body">
      <div style="display:flex;gap:12px;align-items:center;margin-bottom:14px;">
        <img src="${p.img}" style="width:64px;height:64px;border-radius:14px;object-fit:cover;" />
        <div>
          <div style="font-weight:800;color:var(--color-secondary);">${escapeHtml(p.name)}</div>
          <div style="font-size:12px;color:var(--color-text-light);">为它取一个温柔的名字吧</div>
        </div>
      </div>
      <div class="form-row">
        <label class="form-label">小名昵称</label>
        <input class="form-input" id="nick-input" placeholder="例如：小绿、肉肉..." value="" />
      </div>
      <div class="form-row">
        <label class="form-label">植物头像 <span style="font-weight:500;color:var(--color-text-muted);font-size:11px;">（可选 · 拍张照片更有归属感）</span></label>
        <div class="avatar-uploader" id="avatar-uploader">
          <div class="avatar-preview" id="avatar-preview">
            <i class="ri-camera-line"></i>
            <span>点击上传</span>
          </div>
          <div class="avatar-uploader-tip">
            <div style="font-size:13px;font-weight:700;color:var(--color-secondary);">为它拍张照片 📸</div>
            <div style="font-size:11px;color:var(--color-text-light);margin-top:4px;line-height:1.6;">
              不上传则使用默认图片，<br/>之后也可以在小院里随时替换～
            </div>
            <button type="button" class="btn btn-ghost btn-sm" id="clear-avatar" style="margin-top:6px;display:none;">
              <i class="ri-close-line"></i> 清除
            </button>
          </div>
          <input type="file" accept="image/*" capture="environment" id="adopt-avatar-input" style="display:none;" />
        </div>
      </div>
      <div class="form-row">
        <label class="form-label">摆放位置</label>
        <select class="form-select" id="loc-input">
          <option value="客厅">客厅</option>
          <option value="卧室">卧室</option>
          <option value="阳台">阳台</option>
          <option value="书房">书房</option>
          <option value="厨房窗台">厨房窗台</option>
          <option value="办公桌">办公桌</option>
          <option value="玄关">玄关</option>
        </select>
      </div>
      <button class="btn btn-primary btn-block" id="confirm-adopt"><i class="ri-heart-line"></i> 确认加入</button>
    </div>
  `);

  let customAvatar = null;
  const avatarInput = document.getElementById('adopt-avatar-input');
  const avatarPreview = document.getElementById('avatar-preview');
  const clearBtn = document.getElementById('clear-avatar');
  avatarPreview.addEventListener('click', () => avatarInput.click());
  avatarInput.addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) { toast('图片过大，请选择 5MB 以内的图片'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      customAvatar = ev.target.result;
      avatarPreview.classList.add('has-image');
      avatarPreview.innerHTML = `<img src="${customAvatar}" alt="预览" />`;
      clearBtn.style.display = 'inline-flex';
    };
    reader.readAsDataURL(f);
  });
  clearBtn.addEventListener('click', () => {
    customAvatar = null;
    avatarInput.value = '';
    avatarPreview.classList.remove('has-image');
    avatarPreview.innerHTML = `<i class="ri-camera-line"></i><span>点击上传</span>`;
    clearBtn.style.display = 'none';
  });

  document.getElementById('confirm-adopt').addEventListener('click', () => {
    const nick = document.getElementById('nick-input').value.trim() || p.name;
    const loc = document.getElementById('loc-input').value;
    addPlant({
      plantId: p.id,
      nick,
      species: p.name,
      img: customAvatar || p.img,
      location: loc,
    });
    closeModal();
    toast(`🎉 ${nick} 已加入你的小院！`);
  });
}