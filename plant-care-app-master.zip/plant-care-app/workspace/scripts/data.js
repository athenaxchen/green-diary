// 植物图片资源 - 精选高质量图片（清新自然·北欧风·风格统一）
export const IMG = {
  // 绿萝 - 清新藤蔓垂落
  pothos:    'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/411168bf-96fe-4036-9b1c-594f30257a08/image_1778640355_3_1.jpg',
  pothos2:   'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/1182f5c9-23c8-4c68-acfa-b6aa4c2e6dea/image_1778640355_1_1.jpg',
  // 多肉 - 萌系治愈
  succulent: 'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/4723f026-4a57-442d-9118-b2e3d7294745/image_1778641320_5_1.jpg',
  succulent2:'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/d4c62736-baf6-4bcc-abbb-ac70a2e14455/image_1778641320_6_1.jpg',
  // 龟背竹 - 北欧风温暖光线
  monstera:  'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/fcf43e3a-6b28-4f06-9816-fc27d616dea7/image_1778640284_1_1.jpg',
  // 虎皮兰 - 北欧极简
  sansevieria:'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/7a241361-5379-4f2f-aaed-b3c893a2a655/image_1778640369_1_1.jpg',
  // 薄荷 - 清香翠绿厨房
  mint:      'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/0058d75a-a799-44ed-9017-b0530dc0c5e3/image_1778640376_1_1.jpg',
  // 月季 - 粉嫩柔美
  rose:      'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/32312346-3611-4dc5-af38-eb7b45b7c8a6/image_1778641401_6_1.jpg',
  // 栀子花 - 洁白清香
  gardenia:  'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/b24b14e4-2979-400e-a2c1-e6451e22b3b2/image_1778640391_1_1.jpg',
  // 文竹 - 飘逸文艺
  asparagus: 'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/24af4a4c-9b77-408d-87f7-ba830e67d4ba/image_1778640403_1_3.jpg',
  // 琴叶榕 - 北欧大型绿植
  fiddle:    'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/0f8c8a60-12fd-43af-b6bb-2aaea11ffbe6/image_1778641327_6_3.jpg',
  // 蝴蝶兰 - 优雅
  orchid:    'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/b97502d1-4ddc-4e18-97f4-68998c083935/image_1778640422_1_3.jpg',
  // 吊兰 - 悬挂飘逸
  spider:    'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/acebdb33-be0e-4743-98dc-4c574a8c8081/image_1778640429_1_1.jpg',
  // 芦荟 - 简约盆栽
  aloe:      'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/f3a750d2-172f-4628-b13c-ad7e72c628c4/image_1778640447_1_3.jpg',
  // 茉莉花 - 洁白清新
  jasmine:   'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/7459e314-8f7b-4c63-96a3-21e365b8aa16/image_1778640462_2_1.jpg',
  // 薰衣草 - 紫色花田
  lavender:  'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/6706eaf2-83cb-4143-a283-fdaba73f4509/image_1778640466_3_1.jpg',
  // 君子兰 - 橙色花朵
  clivia:    'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/3f23e879-2f68-4b2c-8fdf-cca9bf12b6d4/image_1778640475_1_1.jpg',
  // 幸福树
  happiness: 'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/f977e19d-c711-4b0f-b875-a132104fa57c/image_1778640483_2_1.jpg',
  // 金钱树（ZZ Plant）
  money:     'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/52fe7eb0-3cc3-44f7-81bd-3dba0aa6e711/image_1778640496_1_3.jpg',
  // Banner - 清新自然背景
  banner:    'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/6a5169a9-825f-474f-b360-fca20354f723/image_1778640509_3_1.jpg',
  banner2:   'https://zhiyan-ai-agent-with-1258344702.cos.ap-guangzhou.tencentcos.cn/with/b0eb9499-f649-4608-abe1-26c790efedbd/image_1778640517_1_1.jpg',
};

// 植物百科库
export const PLANTS = [
  {
    id: 'p_pothos', name: '绿萝', latin: 'Epipremnum aureum', img: IMG.pothos,
    category: ['观叶', '净化空气', '好养易活'], difficulty: 1, light: '散射光', water: '3-5天',
    temp: '15-30°C', humidity: '中等', toxic: '微毒（避免误食）',
    desc: '绿萝是最受欢迎的室内观叶植物之一，藤蔓优雅，叶片呈心形，能有效吸附甲醛、苯等有害气体，被誉为"空气净化器"。',
    tips: ['喜温暖湿润，避免阳光直射', '土壤干透再浇透水即可', '冬季减少浇水，避免积水烂根', '可水培也可土培，水培时1-2周换水', '叶片黄化多因浇水过多或缺光']
  },
  {
    id: 'p_succulent', name: '多肉植物', latin: 'Succulent', img: IMG.succulent,
    category: ['多肉', '萌系', '好养易活'], difficulty: 1, light: '充足阳光', water: '7-10天',
    temp: '15-25°C', humidity: '低', toxic: '无毒',
    desc: '多肉植物形态多样、颜色丰富，以肥厚的叶片储存水分，造型萌系治愈，是阳台与窗台的明星。',
    tips: ['宁干勿湿，土壤干透再浇水', '需要充足光照才能上色', '夏季高温休眠期减少浇水', '使用颗粒土，保持透气', '通风很重要，可避免病害']
  },
  {
    id: 'p_monstera', name: '龟背竹', latin: 'Monstera deliciosa', img: IMG.monstera,
    category: ['观叶', '北欧风', '净化空气'], difficulty: 2, light: '明亮散射光', water: '5-7天',
    temp: '18-28°C', humidity: '较高', toxic: '微毒',
    desc: '龟背竹叶片宽大、孔洞独特，是北欧风、ins风布置的明星植物，热带风情十足。',
    tips: ['喜温暖、忌寒冷，冬季保持10°C以上', '定期擦拭叶面保持光泽', '可立支柱引导气根攀附', '春夏季施薄肥1次/月', '叶尖发黄检查是否积水']
  },
  {
    id: 'p_sansevieria', name: '虎皮兰', latin: 'Sansevieria trifasciata', img: IMG.sansevieria,
    category: ['观叶', '净化空气', '好养易活'], difficulty: 1, light: '半阴-全光', water: '10-15天',
    temp: '15-30°C', humidity: '低-中', toxic: '微毒',
    desc: '虎皮兰耐旱耐阴，被誉为"卧室之王"，能在夜间释放氧气，是少数适合放卧室的植物。',
    tips: ['极耐旱，宁干勿湿', '可承受较暗环境，但不会快速生长', '冬季低于10°C停止浇水', '使用排水良好的沙质土', '繁殖容易，可分株或叶插']
  },
  {
    id: 'p_mint', name: '薄荷', latin: 'Mentha haplocalyx', img: IMG.mint,
    category: ['香草', '可食用', '好养易活'], difficulty: 1, light: '充足阳光', water: '2-3天',
    temp: '15-30°C', humidity: '中-高', toxic: '无毒',
    desc: '薄荷气味清凉提神，可泡茶、调饮、做菜，是阳台香草园的入门首选。',
    tips: ['喜阳光充足、土壤湿润', '生长迅速，需经常修剪', '可扦插快速繁殖', '注意防蚜虫', '摘心可以让植株更茂密']
  },
  {
    id: 'p_rose', name: '月季', latin: 'Rosa chinensis', img: IMG.rose,
    category: ['开花', '阳台', '观赏'], difficulty: 3, light: '全光照', water: '2-4天',
    temp: '15-25°C', humidity: '中', toxic: '无毒',
    desc: '月季有"花中皇后"之称，花期长、花色多，是阳台党的最爱，但需要耐心打理。',
    tips: ['每天至少6小时阳光', '花期前后施磷钾肥', '勤剪枯枝病叶，促进通风', '注意防黑斑病和红蜘蛛', '冬季短截重剪养树形']
  },
  {
    id: 'p_gardenia', name: '栀子花', latin: 'Gardenia jasminoides', img: IMG.gardenia,
    category: ['开花', '香味', '观赏'], difficulty: 3, light: '半阴-散射光', water: '2-3天',
    temp: '16-28°C', humidity: '高', toxic: '无毒',
    desc: '栀子花洁白芬芳，花香浓郁醇厚，是夏日的诗意代表。喜酸性土，需要细心呵护。',
    tips: ['喜酸性土，定期浇硫酸亚铁', '保持空气湿度，常喷雾', '避开正午强光', '花后及时修剪', '叶片发黄多为缺铁或碱性土']
  },
  {
    id: 'p_asparagus', name: '文竹', latin: 'Asparagus setaceus', img: IMG.asparagus,
    category: ['观叶', '文艺', '书房'], difficulty: 2, light: '散射光', water: '3-5天',
    temp: '15-25°C', humidity: '较高', toxic: '无毒',
    desc: '文竹叶如绿云，姿态飘逸，是书房雅置的绝佳搭档，自带书卷气息。',
    tips: ['喜阴湿，避免阳光直射', '保持空气湿度', '土壤干燥时及时浇水但不积水', '黄叶多由空气干燥引起', '可适当修剪保持株型']
  },
  {
    id: 'p_fiddle', name: '琴叶榕', latin: 'Ficus lyrata', img: IMG.fiddle,
    category: ['观叶', '北欧风', '大型绿植'], difficulty: 3, light: '明亮散射光', water: '5-7天',
    temp: '18-28°C', humidity: '中-高', toxic: '微毒',
    desc: '琴叶榕高大优雅，叶片如提琴形状，是网红绿植界的"颜值担当"。',
    tips: ['对环境变化敏感，少搬动', '需要明亮散射光', '土壤表面干透再浇水', '定期擦拭叶面', '掉叶多因环境突变或浇水不当']
  },
  {
    id: 'p_orchid', name: '蝴蝶兰', latin: 'Phalaenopsis', img: IMG.orchid,
    category: ['开花', '高雅', '送礼'], difficulty: 3, light: '明亮散射光', water: '7-10天',
    temp: '18-28°C', humidity: '高', toxic: '无毒',
    desc: '蝴蝶兰花姿优雅如蝶，是高雅与浪漫的代表，常作为节庆送礼的首选花卉。',
    tips: ['使用专用兰花植料（树皮+水苔）', '浇水浸盆法，宁干勿湿', '高温高湿但通风要好', '花后剪去残枝可二次开花', '避免淋雨和阳光直射']
  },
  {
    id: 'p_spider', name: '吊兰', latin: 'Chlorophytum comosum', img: IMG.spider,
    category: ['观叶', '净化空气', '好养易活'], difficulty: 1, light: '散射光', water: '3-5天',
    temp: '15-25°C', humidity: '中', toxic: '无毒',
    desc: '吊兰叶片细长翠绿，能净化空气，繁殖容易，悬挂或摆放都好看。',
    tips: ['喜湿润但忌积水', '夏季避开直射光', '叶尖枯黄常因水质或干燥', '小苗可直接扦插', '换盆建议每1-2年一次']
  },
  {
    id: 'p_aloe', name: '芦荟', latin: 'Aloe vera', img: IMG.aloe,
    category: ['多肉', '可食用', '好养易活'], difficulty: 1, light: '充足光照', water: '10-15天',
    temp: '15-30°C', humidity: '低', toxic: '部分品种内服需谨慎',
    desc: '芦荟既好养又实用，叶片汁液可用于护肤、烫伤辅助，是家中必备的"小药箱"。',
    tips: ['极耐旱，宁干勿湿', '冬季控水保护', '使用沙质土，排水透气', '繁殖容易，可分株或叶插', '低温会冻伤，注意保温']
  },
  {
    id: 'p_jasmine', name: '茉莉花', latin: 'Jasminum sambac', img: IMG.jasmine,
    category: ['开花', '香味', '阳台'], difficulty: 2, light: '充足阳光', water: '2-3天',
    temp: '20-30°C', humidity: '中-高', toxic: '无毒',
    desc: '茉莉花洁白芬芳，香气清雅悠长，是夏日傍晚最治愈的花香。',
    tips: ['喜光，每天至少4小时直射光', '生长期勤施薄肥', '花后及时修剪促二次开花', '冬季减少浇水，避免冻伤', '"晒不死的茉莉，淹不死的栀子"']
  },
  {
    id: 'p_lavender', name: '薰衣草', latin: 'Lavandula', img: IMG.lavender,
    category: ['香草', '观赏', '阳台'], difficulty: 3, light: '充足阳光', water: '5-7天',
    temp: '15-25°C', humidity: '低', toxic: '无毒',
    desc: '薰衣草紫色花海般的浪漫风情，香气有舒缓助眠作用，可制作干花或精油。',
    tips: ['喜光耐旱忌湿热', '使用排水极好的碱性土', '夏季高温需通风遮阴', '冬季短截整形', '适合在阳台或庭院地栽']
  },
  {
    id: 'p_clivia', name: '君子兰', latin: 'Clivia miniata', img: IMG.clivia,
    category: ['观叶', '开花', '观赏'], difficulty: 3, light: '散射光', water: '5-7天',
    temp: '15-25°C', humidity: '中', toxic: '微毒',
    desc: '君子兰叶片厚重端庄，花朵华贵，自古有"花中君子"美誉，是中式雅居的代表。',
    tips: ['夏避烈日，冬要充足光', '使用疏松腐殖土', '每周转盆180°保持株型', '花期前增施磷钾肥', '夹箭多为温差不足']
  },
  {
    id: 'p_happiness', name: '幸福树', latin: 'Radermachera sinica', img: IMG.happiness,
    category: ['观叶', '大型绿植', '寓意美好'], difficulty: 2, light: '明亮散射光', water: '3-5天',
    temp: '18-28°C', humidity: '中-高', toxic: '无毒',
    desc: '幸福树寓意美好，株型挺拔，叶片层层叠叠，是客厅、玄关的常用大型绿植。',
    tips: ['喜温暖湿润、明亮散射光', '保持土壤湿润但不积水', '常喷雾增加湿度', '冬季注意保温', '掉叶多因环境突变或低温']
  },
];

// 分类
export const CATEGORIES = [
  { key: 'all', label: '全部', icon: '🌿' },
  { key: '好养易活', label: '好养易活', icon: '✨' },
  { key: '观叶', label: '观叶', icon: '🍃' },
  { key: '开花', label: '开花', icon: '🌸' },
  { key: '多肉', label: '多肉', icon: '🌵' },
  { key: '香草', label: '香草', icon: '🌱' },
  { key: '净化空气', label: '净化空气', icon: '💨' },
  { key: '阳台', label: '阳台', icon: '☀️' },
];

// 我的植物（mock）
export const MY_PLANTS = [
  {
    id: 'm1', plantId: 'p_monstera', nick: '小背背', species: '龟背竹', img: IMG.monstera,
    location: '客厅落地', adoptDate: '2024-08-12', health: 'good',
    diary: [
      { id: 'd1', type: 'water', title: '浇水了 💧', time: '今天 09:20', note: '土干透了，浇了一杯水' },
      { id: 'd2', type: 'photo', title: '拍照打卡 📸', time: '昨天 18:42', note: '又长了一片新叶子！' },
      { id: 'd3', type: 'fertilize', title: '施肥了 🌱', time: '3天前', note: '稀释复合肥液' },
    ]
  },
  {
    id: 'm2', plantId: 'p_succulent', nick: '肉肉一号', species: '多肉拼盘', img: IMG.succulent2,
    location: '南阳台', adoptDate: '2024-05-03', health: 'good',
    diary: [
      { id: 'd1', type: 'water', title: '浇水了 💧', time: '5天前', note: '叶子有点皱，补点水' },
      { id: 'd2', type: 'photo', title: '拍照打卡 📸', time: '一周前', note: '颜色越来越漂亮了' },
    ]
  },
  {
    id: 'm3', plantId: 'p_pothos', nick: '萝萝', species: '绿萝', img: IMG.pothos2,
    location: '书桌上', adoptDate: '2024-10-21', health: 'warn',
    diary: [
      { id: 'd1', type: 'water', title: '浇水了 💧', time: '4天前', note: '换了新位置，光线更好' },
    ]
  },
  {
    id: 'm4', plantId: 'p_mint', nick: '小薄荷', species: '薄荷', img: IMG.mint,
    location: '厨房窗台', adoptDate: '2025-02-08', health: 'good',
    diary: [
      { id: 'd1', type: 'prune', title: '剪枝了 ✂️', time: '2天前', note: '摘心促分枝' },
      { id: 'd2', type: 'water', title: '浇水了 💧', time: '今天 08:00', note: '' },
    ]
  },
];

// 任务类型映射
export const TASK_TYPES = {
  water:     { label: '浇水',   icon: 'ri-contrast-drop-2-line', tag: 'tag-water' },
  fertilize: { label: '施肥',   icon: 'ri-seedling-line',         tag: 'tag-fertilize' },
  prune:     { label: '剪枝',   icon: 'ri-scissors-cut-line',     tag: 'tag-prune' },
  repot:     { label: '换盆',   icon: 'ri-archive-line',          tag: 'tag-repot' },
  rotate:    { label: '转盆',   icon: 'ri-refresh-line',          tag: 'tag-rotate' },
  clean:     { label: '擦叶',   icon: 'ri-leaf-line',             tag: 'tag-clean' },
};

// 今日 & 周内任务（mock）
export const TASKS = [
  { id: 't1', plantId: 'm1', type: 'water',     done: false, dayOffset: 0,  desc: '给小背背浇水' },
  { id: 't2', plantId: 'm3', type: 'water',     done: true,  dayOffset: 0,  desc: '给萝萝浇水' },
  { id: 't3', plantId: 'm4', type: 'prune',     done: false, dayOffset: 0,  desc: '给小薄荷摘心' },
  { id: 't4', plantId: 'm1', type: 'clean',     done: false, dayOffset: 1,  desc: '擦拭龟背竹叶面' },
  { id: 't5', plantId: 'm2', type: 'water',     done: false, dayOffset: 2,  desc: '给肉肉一号浇水' },
  { id: 't6', plantId: 'm1', type: 'fertilize', done: false, dayOffset: 3,  desc: '给小背背施薄肥' },
  { id: 't7', plantId: 'm3', type: 'rotate',    done: false, dayOffset: 4,  desc: '萝萝转盆' },
  { id: 't8', plantId: 'm4', type: 'water',     done: false, dayOffset: 5,  desc: '小薄荷浇水' },
  { id: 't9', plantId: 'm2', type: 'clean',     done: false, dayOffset: -1, desc: '清理多肉枯叶' },
];

// 健康检测历史
export const HEALTH_HISTORY = [
  { id: 'h1', plantId: 'm1', img: IMG.monstera,    score: 92, date: '今天',  status: '健康' },
  { id: 'h2', plantId: 'm3', img: IMG.pothos,      score: 76, date: '3天前', status: '需关注' },
  { id: 'h3', plantId: 'm4', img: IMG.mint,        score: 95, date: '5天前', status: '健康' },
  { id: 'h4', plantId: 'm2', img: IMG.succulent2,  score: 88, date: '一周前', status: '健康' },
];

// 模拟检测结果池
export const HEALTH_RESULT_POOL = [
  {
    score: 92, status: '状态良好',
    issues: [
      { name: '叶面有少许灰尘', tip: '建议用湿布轻轻擦拭叶面，保持光合作用效率', level: 'warn' },
    ]
  },
  {
    score: 78, status: '需要关注',
    issues: [
      { name: '叶尖轻微发黄', tip: '可能是浇水过多或空气干燥，减少浇水频次并喷雾保湿', level: 'warn' },
      { name: '光照可能不足', tip: '建议挪到散射光更好的位置', level: 'warn' },
    ]
  },
  {
    score: 65, status: '需要照护',
    issues: [
      { name: '叶片黄化明显', tip: '检查根部是否有积水烂根，必要时换土', level: 'danger' },
      { name: '可能存在虫害', tip: '检查叶背是否有红蜘蛛或蚜虫，可用稀释皂液喷洒', level: 'danger' },
    ]
  },
  {
    score: 95, status: '生机盎然',
    issues: [
      { name: '继续保持当前养护节奏 🎉', tip: '叶色翠绿、叶形舒展，植物状态非常棒！', level: 'warn' },
    ]
  },
];

// 用户信息（mock）
export const USER = {
  name: '小园丁',
  tag: '🌿 养护达人 · Lv.4',
  totalPlants: 4,
  totalDays: 286,
  streakDays: 32,
  achievements: [
    { name: '初识绿意', icon: '🌱', unlocked: true },
    { name: '七日坚持', icon: '📅', unlocked: true },
    { name: '绿手指',   icon: '🤚', unlocked: true },
    { name: '百科通',   icon: '📖', unlocked: true },
    { name: '花开满院', icon: '🌸', unlocked: false },
    { name: '香草达人', icon: '🌿', unlocked: false },
    { name: '多肉收藏家', icon: '🌵', unlocked: false },
    { name: '园艺大师', icon: '🏆', unlocked: false },
  ]
};