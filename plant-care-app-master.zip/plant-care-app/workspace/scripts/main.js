// 主入口：路由调度 + 状态订阅
import { subscribe } from './store.js';
import { renderDiscover } from './pages/discover.js';
import { renderGarden }   from './pages/garden.js';
import { renderTasks }    from './pages/tasks.js';
import { renderHealth }   from './pages/health.js';
import { renderProfile }  from './pages/profile.js';

const view = document.getElementById('app-view');
const tabBar = document.getElementById('tab-bar');

const PAGE_RENDERERS = {
  discover: renderDiscover,
  garden:   renderGarden,
  tasks:    renderTasks,
  health:   renderHealth,
  profile:  renderProfile,
};

let currentTab = 'tasks';   // 默认首页：今日任务

function navigate(tab) {
  if (!PAGE_RENDERERS[tab]) return;
  currentTab = tab;
  // 切换 active
  tabBar.querySelectorAll('.tab-item').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === tab);
  });
  // 滚回顶
  view.scrollTop = 0;
  // 渲染
  PAGE_RENDERERS[tab](view);
}

// Tab 点击
tabBar.querySelectorAll('.tab-item').forEach(b => {
  b.addEventListener('click', () => navigate(b.dataset.tab));
});

// 状态变更后，重渲染当前页
subscribe(() => {
  PAGE_RENDERERS[currentTab](view);
});

// 状态栏时间更新
function updateStatusTime() {
  const t = document.getElementById('status-time');
  if (!t) return;
  const d = new Date();
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  t.textContent = `${h}:${m}`;
}
updateStatusTime();
setInterval(updateStatusTime, 30000);

// 全局图片加载失败兜底：用渐变背景 + 叶子emoji 替代，避免出现"裂图"
document.addEventListener('error', (e) => {
  const img = e.target;
  if (img && img.tagName === 'IMG' && !img.dataset.fallback) {
    img.dataset.fallback = '1';
    const wrap = img.parentElement;
    if (wrap) {
      const ph = document.createElement('div');
      ph.className = 'img-fallback';
      ph.innerHTML = '🌿';
      // 复制原图的尺寸/圆角
      const cs = getComputedStyle(img);
      ph.style.width  = img.style.width  || cs.width  || '100%';
      ph.style.height = img.style.height || cs.height || '100%';
      ph.style.borderRadius = cs.borderRadius || '12px';
      img.replaceWith(ph);
    } else {
      img.style.display = 'none';
    }
  }
}, true);

// 初次渲染
navigate(currentTab);

// 全局 ESC 关闭 Modal
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('modal-mask')?.classList.remove('show');
  }
});