// 健康检测页
import { store, addHealthRecord } from '../store.js';
import { HEALTH_RESULT_POOL } from '../data.js';
import { escapeHtml, toast } from '../utils.js';

let currentResult = null;

export function renderHealth(view) {
  view.innerHTML = `
    <section class="page">
      <header class="page-header">
        <h1 class="page-title">健康体检 📷</h1>
        <p class="page-subtitle">为植物拍张照，了解它最近的状态</p>
      </header>

      <div class="health-uploader" id="uploader">
        <div class="upload-circle"><i class="ri-camera-lens-line"></i></div>
        <div class="upload-title">拍照检测</div>
        <div class="upload-desc">尽量拍摄植物全貌或问题叶片<br/>清晰、自然光下识别更准确</div>
        <button class="btn btn-primary" id="start-detect"><i class="ri-camera-line"></i> 开始检测</button>
        <input type="file" accept="image/*" id="file-input" style="display:none;" />
      </div>

      <div id="result-area"></div>

      <div class="section-title">
        <h3>历史记录</h3>
        <span class="more">${store.healthHistory.length} 条</span>
      </div>

      ${store.healthHistory.length === 0 ? `
        <div class="empty">
          <span class="empty-icon">📋</span>
          <div class="empty-text">还没有检测记录</div>
        </div>
      ` : `
        <div class="history-row">
          ${store.healthHistory.map(historyItemHtml).join('')}
        </div>
      `}

      <div style="margin-top:18px;padding:14px 16px;background:#fff;border-radius:14px;box-shadow:var(--shadow-sm);">
        <div style="font-size:13px;font-weight:800;color:var(--color-secondary);margin-bottom:8px;">
          <i class="ri-information-line"></i> 关于检测
        </div>
        <p style="font-size:12px;color:var(--color-text-light);line-height:1.7;">
          智能识别系统通过分析叶片颜色、纹理、形态等特征，综合评估植物健康度，并给出针对性建议。当前为体验版，结果仅供参考。
        </p>
      </div>
    </section>
  `;

  view.querySelector('#start-detect').addEventListener('click', () => {
    view.querySelector('#file-input').click();
  });
  view.querySelector('#file-input').addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (f) startDetection(f, view);
  });
}

function startDetection(file, view) {
  const reader = new FileReader();
  reader.onload = (ev) => {
    const url = ev.target.result;
    showAnalyzing(view, url);
    setTimeout(() => {
      const result = HEALTH_RESULT_POOL[Math.floor(Math.random() * HEALTH_RESULT_POOL.length)];
      currentResult = { ...result, img: url };
      renderResult(view, currentResult);
      addHealthRecord({ plantId: store.myPlants[0]?.id || null, img: url, score: result.score, status: result.status });
    }, 1800);
  };
  reader.readAsDataURL(file);
}

function showAnalyzing(view, imgUrl) {
  const ra = view.querySelector('#result-area');
  ra.innerHTML = `
    <div class="health-result">
      <img class="health-result-img" src="${imgUrl}" />
      <div class="health-result-body" style="text-align:center;padding:24px;">
        <div class="upload-circle" style="width:60px;height:60px;font-size:24px;margin:0 auto 12px;"><i class="ri-loader-4-line" style="animation:spin 1s linear infinite;"></i></div>
        <div style="font-size:15px;font-weight:800;color:var(--color-secondary);">🌿 正在识别中...</div>
        <div style="font-size:12px;color:var(--color-text-light);margin-top:6px;">分析叶片色泽、纹理与生长状态</div>
      </div>
    </div>
  `;
}

function renderResult(view, r) {
  const circumference = 2 * Math.PI * 30;
  const dash = (r.score / 100) * circumference;
  const ra = view.querySelector('#result-area');
  ra.innerHTML = `
    <div class="health-result">
      <img class="health-result-img" src="${r.img}" />
      <div class="health-result-body">
        <div class="health-score">
          <div class="score-ring">
            <svg viewBox="0 0 70 70">
              <circle class="score-ring-bg" cx="35" cy="35" r="30"></circle>
              <circle class="score-ring-bar" cx="35" cy="35" r="30" stroke-dasharray="${dash} ${circumference}"></circle>
            </svg>
            <div class="score-text">${r.score}</div>
          </div>
          <div class="score-meta">
            <div class="score-label">健康评分</div>
            <div class="score-status">${escapeHtml(r.status)}</div>
            <div style="margin-top:4px;font-size:11px;color:var(--color-text-muted);">检测于刚刚</div>
          </div>
        </div>

        <div style="font-size:13px;font-weight:800;color:var(--color-secondary);margin:14px 0 8px;">
          🔍 检测发现
        </div>

        <div class="issues-list">
          ${r.issues.map(i => `
            <div class="issue-item ${i.level === 'danger' ? 'danger' : ''}">
              <i class="${i.level === 'danger' ? 'ri-alert-fill' : 'ri-information-fill'}"></i>
              <div>
                <div class="issue-name">${escapeHtml(i.name)}</div>
                <div class="issue-tip">${escapeHtml(i.tip)}</div>
              </div>
            </div>
          `).join('')}
        </div>

        <button class="btn btn-ghost btn-block" id="recheck" style="margin-top:14px;">
          <i class="ri-refresh-line"></i> 重新检测
        </button>
      </div>
    </div>
  `;
  ra.querySelector('#recheck').addEventListener('click', () => {
    ra.innerHTML = '';
    view.querySelector('#file-input').click();
  });

  // 重新刷新历史区域（首次检测后）
  setTimeout(() => {
    const hist = view.querySelector('.history-row');
    if (hist) {
      hist.innerHTML = store.healthHistory.map(historyItemHtml).join('');
    }
  }, 50);
}

function historyItemHtml(h) {
  const color = h.score >= 85 ? 'var(--color-primary-dark)' : h.score >= 70 ? '#C97B3F' : '#B0563E';
  return `
    <div class="history-item">
      <img src="${h.img}" alt="" />
      <div class="history-score" style="color:${color};">${h.score}分</div>
      <div class="history-date">${escapeHtml(h.date)}</div>
    </div>
  `;
}