// 我的小院（My Plants）
import { store, addDiary, deletePlant, addPlant, updatePlantImage } from '../store.js';
import { PLANTS, TASK_TYPES, IMG } from '../data.js';
import { openModal, closeModal, toast, escapeHtml } from '../utils.js';

export function renderGarden(view) {
  const list = store.myPlants;
  view.innerHTML = `
    <section class="page">
      <header class="page-header">
        <h1 class="page-title">我的小院 🪴</h1>
        <p class="page-subtitle">这里是你和植物的小天地，共 ${list.length} 株</p>
      </header>

      <div class="stat-row">
        <div class="stat-item"><div class="stat-num">${list.length}</div><div class="stat-label">植物总数</div></div>
        <div class="stat-item"><div class="stat-num">${list.filter(p=>p.health==='good').length}</div><div class="stat-label">状态良好</div></div>
        <div class="stat-item"><div class="stat-num">${store.user.streakDays}</div><div class="stat-label">连续打卡</div></div>
      </div>

      ${list.length === 0 ? `
        <div class="empty">
          <span class="empty-icon">🌱</span>
          <div class="empty-text">还没有植物哦，去发现页找一株吧～</div>
          <button class="btn btn-primary" id="goto-discover"><i class="ri-search-line"></i> 去发现植物</button>
        </div>
      ` : `
        <div class="my-plant-list">
          ${list.map(plantCardHtml).join('')}
        </div>
      `}
    </section>
    <button class="fab" id="add-plant-fab" title="添加植物"><i class="ri-add-line"></i></button>
  `;

  // 事件
  view.querySelectorAll('.my-plant-card').forEach(card => {
    card.addEventListener('click', () => openMyPlantDetail(card.dataset.id));
  });
  const fab = view.querySelector('#add-plant-fab');
  if (fab) fab.addEventListener('click', () => openAddSheet());
  const gd = view.querySelector('#goto-discover');
  if (gd) gd.addEventListener('click', () => {
    document.querySelector('[data-tab="discover"]').click();
  });
}

function plantCardHtml(p) {
  const days = daysSince(p.adoptDate);
  const healthMap = {
    good: { dot: 'health-good', text: '状态良好' },
    warn: { dot: 'health-warn', text: '需关注' },
    bad:  { dot: 'health-bad',  text: '需照护' },
  };
  const h = healthMap[p.health] || healthMap.good;
  return `
    <article class="my-plant-card" data-id="${p.id}">
      <img class="my-plant-img" src="${p.img}" alt="${escapeHtml(p.nick)}" loading="lazy" />
      <div class="my-plant-info">
        <div class="my-plant-nick">
          ${escapeHtml(p.nick)}
          <span class="health-dot ${h.dot}"></span>
        </div>
        <div class="my-plant-species">${escapeHtml(p.species)} · ${escapeHtml(p.location)}</div>
        <div class="my-plant-meta">
          <span><i class="ri-calendar-line"></i> 共 ${days} 天</span>
          <span><i class="ri-heart-pulse-line"></i> ${h.text}</span>
        </div>
      </div>
      <i class="ri-arrow-right-s-line" style="color:var(--color-text-muted);font-size:20px;"></i>
    </article>
  `;
}

function daysSince(dateStr) {
  const d1 = new Date(dateStr);
  const d2 = new Date();
  return Math.max(1, Math.floor((d2 - d1) / (1000 * 60 * 60 * 24)));
}

function openMyPlantDetail(id) {
  const p = store.myPlants.find(x => x.id === id);
  if (!p) return;
  const days = daysSince(p.adoptDate);
  openModal(`
    <div class="my-detail-cover">
      <img src="${p.img}" alt="${escapeHtml(p.nick)}" id="my-detail-img" />
      <div class="my-detail-cover-overlay">
        <div class="my-detail-nick">${escapeHtml(p.nick)}</div>
        <div class="my-detail-sub">${escapeHtml(p.species)} · ${escapeHtml(p.location)} · 陪伴 ${days} 天</div>
      </div>
      <button class="cover-edit-btn" id="change-avatar-btn" title="更换头像">
        <i class="ri-camera-line"></i>
      </button>
      <input type="file" accept="image/*" capture="environment" id="avatar-file-input" style="display:none;" />
      <button class="modal-close" data-close style="position:absolute;top:14px;right:14px;background:rgba(255,255,255,0.85);"><i class="ri-close-line"></i></button>
    </div>
    <div class="modal-body">
      <div class="action-row">
        <button class="action-btn water"     data-act="water"><i class="ri-contrast-drop-2-line"></i><span>浇水</span></button>
        <button class="action-btn fertilize" data-act="fertilize"><i class="ri-seedling-line"></i><span>施肥</span></button>
        <button class="action-btn prune"     data-act="prune"><i class="ri-scissors-cut-line"></i><span>剪枝</span></button>
        <button class="action-btn photo"     data-act="photo"><i class="ri-camera-line"></i><span>打卡</span></button>
      </div>

      <div class="section-title" style="margin-top:6px;">
        <h3>成长日记</h3>
        <span class="more">${p.diary.length} 条</span>
      </div>

      <div class="diary-list" id="diary-list">
        ${p.diary.length ? p.diary.map(diaryItemHtml).join('') : `
          <div class="empty" style="padding:30px 10px;">
            <span class="empty-icon">📖</span>
            <div class="empty-text">还没有日记，来记录第一笔吧～</div>
          </div>
        `}
      </div>

      <button class="btn btn-ghost btn-block" id="del-plant" style="margin-top:18px;">
        <i class="ri-delete-bin-line"></i> 把它从小院移除
      </button>
    </div>
  `);

  document.querySelectorAll('.action-btn[data-act]').forEach(b => {
    b.addEventListener('click', () => {
      const act = b.dataset.act;
      const map = {
        water:     { type: 'water',     title: '浇水了 💧', note: '土壤湿润，状态不错' },
        fertilize: { type: 'fertilize', title: '施肥了 🌱', note: '稀释复合肥液' },
        prune:     { type: 'prune',     title: '剪枝了 ✂️', note: '修剪枯黄枝叶' },
        photo:     { type: 'photo',     title: '拍照打卡 📸', note: '又长大了一点' },
      };
      addDiary(p.id, map[act]);
      toast(`✅ ${map[act].title}`);
      closeModal();
    });
  });

  document.getElementById('del-plant').addEventListener('click', () => {
    if (confirm(`确定要把「${p.nick}」从小院移除吗？相关任务也会一起删除。`)) {
      deletePlant(p.id);
      closeModal();
      toast('已移除');
    }
  });

  // 更换头像
  const fileInput = document.getElementById('avatar-file-input');
  document.getElementById('change-avatar-btn').addEventListener('click', () => {
    fileInput.click();
  });
  fileInput.addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) { toast('图片过大，请选择 5MB 以内的图片'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target.result;
      // 即时预览
      const imgEl = document.getElementById('my-detail-img');
      if (imgEl) imgEl.src = dataUrl;
      updatePlantImage(p.id, dataUrl);
      toast('🌿 头像已更新');
      closeModal();
    };
    reader.readAsDataURL(f);
  });
}

function diaryItemHtml(d) {
  const colorMap = {
    water:     { bg: '#DEEEF6', color: '#3E7D9E', icon: 'ri-contrast-drop-2-fill' },
    fertilize: { bg: '#F0E6CF', color: '#8C6A2B', icon: 'ri-seedling-fill' },
    prune:     { bg: '#E5E1F2', color: '#6B5BA0', icon: 'ri-scissors-cut-fill' },
    photo:     { bg: 'rgba(127,176,105,0.18)', color: '#5A8A4A', icon: 'ri-camera-fill' },
    default:   { bg: '#EEE', color: '#666', icon: 'ri-bookmark-fill' },
  };
  const c = colorMap[d.type] || colorMap.default;
  return `
    <div class="diary-item">
      <div class="diary-icon" style="background:${c.bg};color:${c.color};"><i class="${c.icon}"></i></div>
      <div class="diary-content">
        <div class="diary-title">${escapeHtml(d.title)}</div>
        <div class="diary-time">${escapeHtml(d.time)}</div>
        ${d.note ? `<div class="diary-note">${escapeHtml(d.note)}</div>` : ''}
      </div>
    </div>
  `;
}

function openAddSheet() {
  openModal(`
    <div class="modal-header">
      <span class="modal-title">添加新植物 🌱</span>
      <button class="modal-close" data-close><i class="ri-close-line"></i></button>
    </div>
    <div class="modal-body">
      <p style="font-size:13px;color:var(--color-text-light);margin-bottom:10px;">从图鉴中挑选一种：</p>
      <div class="species-grid" id="species-grid">
        ${PLANTS.map(p => `
          <div class="species-pick" data-id="${p.id}">
            <img src="${p.img}" alt="${escapeHtml(p.name)}" />
            <div class="species-pick-name">${escapeHtml(p.name)}</div>
          </div>
        `).join('')}
      </div>

      <div class="form-row" style="margin-top:14px;">
        <label class="form-label">植物头像 <span style="font-weight:500;color:var(--color-text-muted);font-size:11px;">（可选 · 拍照或从相册选择）</span></label>
        <div class="avatar-uploader" id="avatar-uploader">
          <div class="avatar-preview" id="avatar-preview">
            <i class="ri-camera-line"></i>
            <span>点击上传</span>
          </div>
          <div class="avatar-uploader-tip">
            <div style="font-size:13px;font-weight:700;color:var(--color-secondary);">为它拍一张照片吧 📸</div>
            <div style="font-size:11px;color:var(--color-text-light);margin-top:4px;line-height:1.6;">
              不上传则使用图鉴默认图片，<br/>之后也可以在小院里随时替换哦～
            </div>
            <button type="button" class="btn btn-ghost btn-sm" id="clear-avatar" style="margin-top:6px;display:none;">
              <i class="ri-close-line"></i> 清除
            </button>
          </div>
          <input type="file" accept="image/*" capture="environment" id="add-avatar-input" style="display:none;" />
        </div>
      </div>

      <div class="form-row">
        <label class="form-label">小名昵称</label>
        <input class="form-input" id="nick2" placeholder="给它起个名字" />
      </div>
      <div class="form-row">
        <label class="form-label">摆放位置</label>
        <select class="form-select" id="loc2">
          <option>客厅</option><option>卧室</option><option>阳台</option>
          <option>书房</option><option>厨房窗台</option><option>办公桌</option><option>玄关</option>
        </select>
      </div>
      <button class="btn btn-primary btn-block" id="confirm-add"><i class="ri-check-line"></i> 加入小院</button>
    </div>
  `);

  let pickedId = null;
  let customAvatar = null;

  document.querySelectorAll('.species-pick').forEach(el => {
    el.addEventListener('click', () => {
      document.querySelectorAll('.species-pick').forEach(x => x.classList.remove('active'));
      el.classList.add('active');
      pickedId = el.dataset.id;
    });
  });

  // 头像上传
  const avatarInput = document.getElementById('add-avatar-input');
  const avatarPreview = document.getElementById('avatar-preview');
  const clearBtn = document.getElementById('clear-avatar');
  avatarPreview.addEventListener('click', () => avatarInput.click());
  avatarInput.addEventListener('change', (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) { toast('图片过大，请选择 5MB 以内的图片'); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      customAvatar = ev.target.result;
      avatarPreview.classList.add('has-image');
      avatarPreview.innerHTML = `<img src="${customAvatar}" alt="预览" />`;
      clearBtn.style.display = 'inline-flex';
    };
    reader.readAsDataURL(f);
  });
  clearBtn.addEventListener('click', () => {
    customAvatar = null;
    avatarInput.value = '';
    avatarPreview.classList.remove('has-image');
    avatarPreview.innerHTML = `<i class="ri-camera-line"></i><span>点击上传</span>`;
    clearBtn.style.display = 'none';
  });

  document.getElementById('confirm-add').addEventListener('click', () => {
    if (!pickedId) { toast('请先选一种植物哦 🌿'); return; }
    const p = PLANTS.find(x => x.id === pickedId);
    const nick = document.getElementById('nick2').value.trim() || p.name;
    const loc = document.getElementById('loc2').value;
    addPlant({
      plantId: p.id,
      nick,
      species: p.name,
      img: customAvatar || p.img,
      location: loc,
    });
    closeModal();
    toast(`🎉 ${nick} 已加入你的小院！`);
  });
}